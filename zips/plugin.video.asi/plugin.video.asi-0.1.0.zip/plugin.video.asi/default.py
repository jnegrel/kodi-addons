"""Entry point that Kodi runs (see addon.xml); the work is in resources/lib/plugin.py."""

import sys

from resources.lib import plugin

plugin.main(sys.argv)
