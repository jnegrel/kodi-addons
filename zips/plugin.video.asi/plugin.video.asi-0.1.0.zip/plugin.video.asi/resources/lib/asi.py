"""Client for the Arrêt sur images API and its video hosts, without any Kodi code.

The website (www.arretsurimages.net) is an Angular application that reads everything from
https://api.arretsurimages.net:
- /api/public/contents: the publications, newest first. Filters are "aggregates":
  aggregates[hasAssociatedVideo][video_only]=1, aggregates[content_type_slug][<slug>]=1,
  aggregates[theme_slug][<slug>]=1, plus q=<words> for a search. Pages are asked with the
  header "Range: objects <first>-<last>", and the answer tells the total in Content-Range.
- /api/public/content-types: the programmes (the 7/8, "Arrêt sur images", Proxy...).
- /api/public/themes: the themes.
- /oauth/v2/token: login (OAuth2 password grant, with the website's own public client id).
  The access token goes in the query string (access_token=...), as the website does.

Without a subscription, the API gives an excerpt of subscriber-only videos.

Most videos are on ASI's PeerTube (videos.arretsurimages.net), old shows included: its API
gives an HLS playlist that Kodi plays. Some are on Dailymotion, and a few old ones on Vimeo or
YouTube: those only play in their own player, so they are handed to Kodi's add-on for that site.
"""

import hashlib
import html
import http.client
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

API = 'https://api.arretsurimages.net'
SITE = 'https://www.arretsurimages.net'
PEERTUBE = 'https://videos.arretsurimages.net'
# The website's OAuth client: public, it is in the JavaScript that every visitor downloads
CLIENT_ID = '1_1e3dazertyukilygfos7ldzertyuof7pfd'
CLIENT_SECRET = '2r8yd4a8un0fn45d93acfr3efrgthzdheifhrehihidg4dk5kds7ds23'
TIMEOUT = 20
TRIES = 3  # the API often cuts long answers: try again
PAGE_SIZE = 30

PEERTUBE_ID = re.compile(r'[1-9A-HJ-NP-Za-km-z]{22}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')


class Error(Exception):
    """A network or API error, with a message for the log."""


class LoginError(Error):
    """The API refused the e-mail address or the password."""


class Unavailable(Error):
    """The video cannot be played (removed, private, unknown host)."""


def http_request(url, user_agent, data=None, headers=None, opener=urllib.request.urlopen):
    """GET (or POST with data) a URL. Returns (status, headers, body bytes).
    HTTP errors are returned too, not raised; network errors raise Error after TRIES tries."""
    request = urllib.request.Request(url, data=data, headers={'User-Agent': user_agent, **(headers or {})})
    for attempt in range(TRIES):
        try:
            with opener(request, timeout=TIMEOUT) as response:
                return response.status, response.headers, response.read()
        except urllib.error.HTTPError as error:
            return error.code, error.headers, error.read()
        except (urllib.error.URLError, http.client.HTTPException, socket.timeout, OSError) as error:
            if attempt == TRIES - 1:
                raise Error('{}: {}'.format(_safe(url), error))


def _safe(url):
    """The URL without the access token, for the log."""
    return re.sub(r'access_token=[^&]+', 'access_token=...', url)


def _json(status, body, url):
    try:
        return json.loads(body.decode('utf-8'))
    except ValueError:
        raise Error('{}: HTTP {}, not JSON ({} bytes)'.format(_safe(url), status, len(body)))


def text(value):
    """Plain text from the API's HTML snippets."""
    value = re.sub(r'<br\s*/?>|</p>', '\n', value or '', flags=re.I)
    value = html.unescape(re.sub(r'<[^>]+>', '', value))
    return re.sub(r'\n{3,}', '\n\n', re.sub(r'[ \t]+', ' ', value)).strip()


def image_url(media, size='thumbnail'):
    """URL of a media (thumbnail, cover...): size is thumbnail, square, article_header or original."""
    if not isinstance(media, dict) or not media.get('slug'):
        return ''
    if media.get('provider') not in ('image', 'cover'):
        return image_url(media.get('cover'), size)
    return '{}/api/public/media/{}/action/show?format={}&t={}'.format(
        API, urllib.parse.quote(media['slug']), size, urllib.parse.quote(media.get('updated_at') or ''))


def video_source(video):
    """(host, id) of an associated video: host is peertube, dailymotion, vimeo or youtube.
    None when there is no video."""
    if not isinstance(video, dict):
        return None
    metas = video.get('metas') if isinstance(video.get('metas'), dict) else {}
    urls = [video.get('reference_url') or '', metas.get('embed_url') or '']
    ref = str(video.get('reference_id') or '')
    kind = '{} {} {}'.format(video.get('provider'), video.get('mime_type'), ' '.join(urls)).lower()
    for url in urls:
        match = re.search(r'videos\.arretsurimages\.net/(?:w|videos/(?:watch|embed))/([A-Za-z0-9-]+)', url)
        if match:
            return 'peertube', match.group(1)
    # Old videos moved from Dailymotion to PeerTube kept their mime type: the id tells
    if 'peertube' in kind or PEERTUBE_ID.fullmatch(ref):
        return ('peertube', ref) if ref else None
    if 'dailymotion' in kind:
        for url in urls:
            # the embed URL has the private id (k...) that the player needs
            match = re.search(r'[?&]video=([A-Za-z0-9]+)|dailymotion\.com/(?:embed/)?(?:video|swf)/([A-Za-z0-9]+)', url)
            if match:
                return 'dailymotion', match.group(1) or match.group(2)
        return ('dailymotion', ref) if ref else None
    if 'vimeo' in kind:
        for url in urls:
            match = re.search(r'vimeo\.com/(?:video/)?(\d+)', url)
            if match:
                return 'vimeo', match.group(1)
        return ('vimeo', ref) if ref.isdigit() else None
    if 'youtube' in kind or 'youtu.be' in kind:
        for url in urls:
            match = re.search(r'(?:[?&]v=|/embed/|youtu\.be/)([A-Za-z0-9_-]{11})', url)
            if match:
                return 'youtube', match.group(1)
        return ('youtube', ref) if ref else None
    return None


def episode(content):
    """What the add-on shows of a publication (a dict from /api/public/contents)."""
    video = content.get('associated_video') if isinstance(content.get('associated_video'), dict) else None
    programme = content.get('content_type') or {}
    return {
        'slug': content.get('slug', ''),
        'path': content.get('path', ''),
        'title': text(content.get('title')),
        'plot': text(content.get('lead') or content.get('tease') or content.get('subtitle')),
        'published': content.get('published_at') or '',
        'programme': programme.get('title') or programme.get('label') or '',
        'authors': [a.get('name') for a in content.get('authors') or [] if a.get('name')],
        'free': content.get('access_level') == 'free',
        'duration': (video or {}).get('video_duration') or 0,
        'thumb': image_url(content.get('thumbnail')) or image_url((video or {}).get('cover')),
        'source': video_source(video),
    }


def is_subscribed(profile):
    """Whether the profile (from /api/public/profile) has a running subscription."""
    if not isinstance(profile, dict) or profile.get('error'):
        return False
    roles = profile.get('roles')
    if isinstance(roles, (list, dict)):
        return 'user.subscribed' in roles
    # the website reads roles with hasRole("user.subscribed"); be lenient about where they are
    return 'user.subscribed' in json.dumps(profile)


class Client:
    """The API, with an optional login. `tokens` is a dict that the caller saves between runs
    (access_token, refresh_token, expires_at, account); it is changed in place."""

    def __init__(self, user_agent, tokens=None, username='', password='', opener=urllib.request.urlopen,
                 clock=time.time, log=lambda message: None):
        self.user_agent = user_agent
        self.tokens = tokens if tokens is not None else {}
        self.username = username.strip()
        self.password = password
        self.opener = opener
        self.clock = clock
        self.log = log

    # --- login ---------------------------------------------------------------------------

    def account(self):
        """Fingerprint of the e-mail address and password in the settings: when they change,
        the saved tokens are thrown away."""
        if not (self.username and self.password):
            return ''
        return hashlib.sha256('{}\n{}'.format(self.username.lower(), self.password).encode()).hexdigest()

    def _token_request(self, fields):
        body = json.dumps(dict(fields, client_id=CLIENT_ID, client_secret=CLIENT_SECRET)).encode()
        url = API + '/oauth/v2/token'
        status, _, answer = http_request(url, self.user_agent, data=body, opener=self.opener,
                                         headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
        answer = _json(status, answer, url) if answer else {}
        if status != 200 or not answer.get('access_token'):
            return status, answer
        self.tokens.update(access_token=answer['access_token'], refresh_token=answer.get('refresh_token', ''),
                           expires_at=self.clock() + int(answer.get('expires_in') or 3600) - 60,
                           account=self.account())
        self.tokens.pop('failed', None)
        return status, answer

    def login(self):
        """Logs in with the e-mail address and password. Raises LoginError when refused."""
        self.tokens.clear()
        status, answer = self._token_request(
            {'username': self.username, 'password': self.password, 'grant_type': 'password'})
        if 'access_token' not in self.tokens:
            # remember the refusal: do not try again with the same password at every page
            self.tokens['failed'] = self.account()
            raise LoginError('login refused: HTTP {} {}'.format(status, answer.get('error_description') or answer.get('error') or ''))
        self.log('logged in')

    def token(self):
        """A valid access token, or '' when not logged in."""
        account = self.account()
        if not account or self.tokens.get('failed') == account:
            return ''
        if self.tokens.get('account') != account:
            self.login()
        elif self.clock() >= self.tokens.get('expires_at', 0):
            status, _ = self._token_request({'refresh_token': self.tokens.get('refresh_token', ''),
                                             'grant_type': 'refresh_token'})
            if status != 200 or 'access_token' not in self.tokens:
                self.login()
        return self.tokens.get('access_token', '')

    # --- API -----------------------------------------------------------------------------

    def get(self, path, params=None, first=None, count=None, auth=True):
        """GET an API path. Returns (JSON, total count from Content-Range or None)."""
        params = dict(params or {})
        token = self.token() if auth else ''
        if token:
            params['access_token'] = token
        url = API + path + ('?' + urllib.parse.urlencode(params) if params else '')
        headers = {'Accept': 'application/json'}
        if first is not None:
            headers['Range'] = 'objects {}-{}'.format(first, first + count - 1)
        status, answer_headers, body = http_request(url, self.user_agent, headers=headers, opener=self.opener)
        if status == 401 and token:
            # the token was refused: log in again, once
            self.tokens.clear()
            return self.get(path, {k: v for k, v in params.items() if k != 'access_token'}, first, count, auth)
        if status == 416:  # asked beyond the last item
            return [], None
        data = _json(status, body, url)
        if status not in (200, 206):
            raise Error('{}: HTTP {} {}'.format(_safe(url), status, str(data)[:200]))
        total = None
        match = re.search(r'/(\d+)', (answer_headers or {}).get('Content-Range') or '')
        if match:
            total = int(match.group(1))
        return data, total

    def videos(self, page=1, programme='', theme='', query='', free_only=False, per_page=PAGE_SIZE):
        """A page of publications with a video, newest first. Returns (episodes, total or None)."""
        params = {'aggregates[hasAssociatedVideo][video_only]': 1, 'aggregates[status][published]': 1}
        if free_only:
            params['aggregates[access_level][free]'] = 1
        if programme:
            params['aggregates[content_type_slug][{}]'.format(programme)] = 1
        if theme:
            params['aggregates[theme_slug][{}]'.format(theme)] = 1
        if query:
            params['q'] = query
        params['sort'] = '["published_at","desc"]'
        data, total = self.get('/api/public/contents', params, (page - 1) * per_page, per_page)
        if not isinstance(data, list):
            raise Error('contents: not a list: {}'.format(str(data)[:200]))
        return [episode(c) for c in data if isinstance(c, dict)], total

    def programmes(self):
        """The programmes (émissions) that are online: list of dicts slug, title, thumb."""
        data, _ = self.get('/api/public/content-types', auth=False)
        return [{'slug': t['slug'], 'title': t.get('title') or t.get('label') or t['slug'],
                 'thumb': image_url(t.get('cover'))}
                for t in data if isinstance(t, dict) and t.get('slug') and t.get('status', 'online') == 'online'
                and (t.get('content_format') or {}).get('slug') == 'emission']

    def themes(self):
        """The themes: list of dicts slug, title, plot."""
        data, _ = self.get('/api/public/themes', auth=False)
        themes = [t for t in data if isinstance(t, dict) and t.get('slug') and t.get('is_online', True)]
        return [{'slug': t['slug'], 'title': text(t.get('name')) or t['slug'], 'plot': text(t.get('description'))}
                for t in sorted(themes, key=lambda t: text(t.get('name')).lower())]

    def content(self, slug):
        """One publication, as the logged-in user sees it (the full video for subscribers)."""
        data, _ = self.get('/api/public/contents/' + urllib.parse.quote(slug))
        if not isinstance(data, dict) or 'slug' not in data:
            raise Unavailable('content {}: {}'.format(slug, str(data)[:200]))
        return data

    def profile(self):
        """The logged-in user's profile, or None when not logged in."""
        if not self.token():
            return None
        data, _ = self.get('/api/public/profile')
        return data

    # --- video hosts ---------------------------------------------------------------------

    def stream(self, source):
        """What Kodi plays for a video: (url, headers, mime type). For Vimeo and YouTube,
        a plugin:// URL of Kodi's add-on for that site."""
        host, video_id = source
        if host == 'peertube':
            return self.peertube(video_id)
        if host == 'dailymotion':
            return 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url={}'.format(video_id), {}, ''
        if host == 'vimeo':
            return 'plugin://plugin.video.vimeo/play/?video_id={}'.format(video_id), {}, ''
        if host == 'youtube':
            return 'plugin://plugin.video.youtube/play/?video_id={}'.format(video_id), {}, ''
        raise Unavailable('unknown video host {}'.format(host))

    def peertube(self, video_id):
        url = '{}/api/v1/videos/{}'.format(PEERTUBE, urllib.parse.quote(video_id))
        status, _, body = http_request(url, self.user_agent, opener=self.opener)
        data = _json(status, body, url)
        if status != 200:
            raise Unavailable('PeerTube {}: HTTP {} {}'.format(video_id, status, data.get('detail') or data.get('error') or ''))
        for playlist in data.get('streamingPlaylists') or []:
            if playlist.get('playlistUrl'):
                return playlist['playlistUrl'], {}, 'application/vnd.apple.mpegurl'
        files = [f for f in data.get('files') or [] if f.get('fileUrl')]
        files.sort(key=lambda f: (f.get('resolution') or {}).get('id') or 0)
        if files:
            return files[-1]['fileUrl'], {}, 'video/mp4'
        raise Unavailable('PeerTube {}: no file'.format(video_id))
