"""Kodi side of the add-on: menus, video lists, playback, login state.

Kodi runs default.py for every folder and every video, with
argv = [plugin://plugin.video.asi/, handle, ?action=...&...].
"""

import json
import os
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import asi

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
SEARCHES_KEPT = 10
SUBSCRIPTION_CHECK = 3600  # seconds between checks of the subscription


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(ADDON_ID, message), level)


def tr(string_id):
    return ADDON.getLocalizedString(string_id)


def notify(message, icon=xbmcgui.NOTIFICATION_WARNING):
    xbmcgui.Dialog().notification(ADDON.getAddonInfo('name'), message, icon, 6000)


class Store:
    """A small JSON file in the add-on's data folder (tokens, searches)."""

    def __init__(self, name):
        folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        os.makedirs(folder, exist_ok=True)
        self.path = os.path.join(folder, name)
        try:
            with open(self.path, encoding='utf-8') as f:
                self.data = json.load(f)
        except (OSError, ValueError):
            self.data = {}
        self.saved = json.dumps(self.data, sort_keys=True)

    def save(self):
        if json.dumps(self.data, sort_keys=True) != self.saved:
            with open(self.path, 'w', encoding='utf-8') as f:
                json.dump(self.data, f)
            self.saved = json.dumps(self.data, sort_keys=True)


class Plugin:
    def __init__(self, argv, client=None):
        self.base = argv[0]
        self.handle = int(argv[1])
        self.params = {k: v[0] for k, v in urllib.parse.parse_qs(argv[2].lstrip('?')).items()}
        self.tokens = Store('tokens.json')
        self.client = client or asi.Client(
            '{}/{} (Kodi {})'.format(ADDON_ID, ADDON.getAddonInfo('version'),
                                     xbmc.getInfoLabel('System.BuildVersion').split(' ')[0] or '?'),
            tokens=self.tokens.data, username=ADDON.getSetting('username'),
            password=ADDON.getSetting('password'), log=log)

    def url(self, **params):
        return self.base + '?' + urllib.parse.urlencode({k: v for k, v in params.items() if v not in ('', None)})

    def run(self):
        action = self.params.get('action', 'menu')
        try:
            getattr(self, 'do_' + action, self.do_menu)()
        except asi.LoginError as error:
            log(str(error), xbmc.LOGWARNING)
            notify(tr(30030))
            if action != 'play':
                self.end(False)
        except asi.Error as error:
            log(str(error), xbmc.LOGERROR)
            notify(tr(30031) if not isinstance(error, asi.Unavailable) else tr(30032))
            if action == 'play':
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            else:
                self.end(False)
        finally:
            self.tokens.save()

    # --- login state ---------------------------------------------------------------------

    def subscribed(self):
        """True for a subscriber, False when logged in without a subscription, None when not
        logged in. A login error is told once, then the add-on goes on without login."""
        try:
            if not self.client.token():
                return None
        except asi.LoginError as error:
            log(str(error), xbmc.LOGWARNING)
            notify(tr(30030))
            return None
        check = self.tokens.data.get('subscribed')
        if not check or check.get('account') != self.client.account() or \
                self.client.clock() - check.get('time', 0) > SUBSCRIPTION_CHECK:
            subscribed = asi.is_subscribed(self.client.profile())
            self.tokens.data['subscribed'] = {'account': self.client.account(), 'time': self.client.clock(),
                                              'value': subscribed}
            log('logged in, {}subscribed'.format('' if subscribed else 'not '))
        return self.tokens.data['subscribed']['value']

    # --- folders -------------------------------------------------------------------------

    def folder(self, label, url, thumb='', plot=''):
        item = xbmcgui.ListItem(label)
        icon = thumb or os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icon.png')
        item.setArt({'thumb': icon, 'icon': icon, 'poster': icon,
                     'fanart': os.path.join(ADDON.getAddonInfo('path'), 'resources', 'fanart.jpg')})
        if plot:
            set_info(item, {'plot': plot})
        xbmcplugin.addDirectoryItem(self.handle, url, item, isFolder=True)

    def end(self, succeeded=True, content='', cache=True):
        if content:
            xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded, cacheToDisc=cache)

    def do_menu(self):
        self.folder(tr(30001), self.url(action='videos'))
        self.folder(tr(30002), self.url(action='programmes'))
        self.folder(tr(30003), self.url(action='themes'))
        self.folder(tr(30004), self.url(action='searches'))
        subscribed = self.subscribed()
        status = {None: tr(30011), False: tr(30012), True: tr(30013)}[subscribed]
        self.folder('{}: {}'.format(tr(30010), status), self.url(action='settings'), plot=tr(30014))
        self.end(cache=False)

    def do_settings(self):
        self.end(False)  # not a folder: Kodi stays on the menu, which is refreshed after
        ADDON.openSettings()
        self.tokens.data.pop('subscribed', None)
        xbmc.executebuiltin('Container.Refresh')

    def do_programmes(self):
        for programme in self.client.programmes():
            self.folder(programme['title'], self.url(action='videos', programme=programme['slug']), programme['thumb'])
        self.end()

    def do_themes(self):
        for theme in self.client.themes():
            self.folder(theme['title'], self.url(action='videos', theme=theme['slug']), plot=theme['plot'])
        self.end()

    def do_searches(self):
        self.folder('[B]{}[/B]'.format(tr(30005)), self.url(action='search'))
        for query in self.searches():
            item_url = self.url(action='videos', query=query)
            item = xbmcgui.ListItem(query)
            item.addContextMenuItems([(tr(30006), 'RunPlugin({})'.format(self.url(action='forget', query=query)))])
            xbmcplugin.addDirectoryItem(self.handle, item_url, item, isFolder=True)
        self.end(cache=False)

    def searches(self):
        return [q for q in self.tokens.data.get('searches', []) if isinstance(q, str)]

    def do_search(self):
        query = xbmcgui.Dialog().input(tr(30004)).strip()
        if not query:
            return self.end(False)
        self.tokens.data['searches'] = ([query] + [q for q in self.searches() if q.lower() != query.lower()])[:SEARCHES_KEPT]
        # open the results as their own folder, so that "back" does not ask again
        self.end(False)
        xbmc.executebuiltin('Container.Update({})'.format(self.url(action='videos', query=query)))

    def do_forget(self):
        query = self.params.get('query', '')
        self.tokens.data['searches'] = [q for q in self.searches() if q != query]
        self.tokens.save()
        xbmc.executebuiltin('Container.Refresh')

    def do_videos(self):
        page = int(self.params.get('page', 1))
        programme, theme, query = (self.params.get(k, '') for k in ('programme', 'theme', 'query'))
        subscribed = self.subscribed()
        hide_excerpts = not subscribed and ADDON.getSetting('excerpts') == 'false'
        episodes, total = self.client.videos(page, programme, theme, query, free_only=hide_excerpts)
        shown = 0
        for episode in episodes:
            if not episode['source']:
                continue
            self.add_episode(episode, excerpt=not subscribed and not episode['free'])
            shown += 1
        pages = -(-total // asi.PAGE_SIZE) if total else 0
        if (pages and page < pages) or (not total and len(episodes) == asi.PAGE_SIZE):
            label = tr(30007).format(page + 1, pages) if pages else tr(30008)
            self.folder('[B]{}[/B]'.format(label), self.url(action='videos', programme=programme, theme=theme,
                                                            query=query, page=page + 1))
        if page == 1 and not episodes:
            notify(tr(30015), xbmcgui.NOTIFICATION_INFO)
        log('videos page {} {}{}{}: {} of {}'.format(page, programme, theme, query, shown, total))
        self.end(content='episodes', cache=False)

    def add_episode(self, episode, excerpt):
        title = episode['title']
        label = '{} [COLOR grey]({})[/COLOR]'.format(title, tr(30009)) if excerpt else title
        item = xbmcgui.ListItem(label)
        plot = episode['plot']
        if excerpt:
            plot = '[I]{}[/I]\n\n{}'.format(tr(30016), plot)
        info = {'title': label, 'plot': plot, 'tvshowtitle': episode['programme'],
                'mediatype': 'episode'}
        date = episode['published'][:10]
        if date:
            info.update(premiered=date, aired=date, dateadded=episode['published'][:19].replace('T', ' '),
                        year=int(date[:4]))
        if episode['duration'] and not excerpt:
            info['duration'] = int(episode['duration'])
        if episode['authors']:
            info['director'] = episode['authors']
        set_info(item, info)
        item.setArt({'thumb': episode['thumb'], 'icon': episode['thumb'], 'fanart': episode['thumb']})
        item.setProperty('IsPlayable', 'true')
        host, video_id = episode['source']
        url = self.url(action='play', slug=episode['slug'], host=host, id=video_id, free='1' if episode['free'] else '')
        xbmcplugin.addDirectoryItem(self.handle, url, item, isFolder=False)

    # --- playback ------------------------------------------------------------------------

    def do_play(self):
        source = (self.params.get('host', ''), self.params.get('id', ''))
        slug = self.params.get('slug', '')
        if slug and not self.params.get('free') and self.subscribed():
            # the lists can give the excerpt; the publication itself gives the full video
            full = asi.video_source(self.client.content(slug).get('associated_video'))
            if full:
                source = full
        log('play {} {}:{}'.format(slug, *source))
        url, headers, mime = self.client.stream(source)
        if url.startswith('plugin://'):
            addon_id = url.split('/')[2]
            if not xbmc.getCondVisibility('System.HasAddon({})'.format(addon_id)):
                # Kodi asks whether to install it from its repository; then the video plays
                # when chosen again
                log('{} is not installed'.format(addon_id), xbmc.LOGWARNING)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                xbmc.executebuiltin('InstallAddon({})'.format(addon_id))
                return
        if headers:
            url += '|' + urllib.parse.urlencode(headers)
        item = xbmcgui.ListItem(path=url)
        if mime:
            item.setMimeType(mime)
            item.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.handle, True, item)


def set_info(item, info):
    """Video information on a list item, for Kodi 19 (setInfo) and 20+ (InfoTagVideo)."""
    if not hasattr(item, 'getVideoInfoTag'):
        item.setInfo('video', info)
        return
    tag = item.getVideoInfoTag()
    setters = {'title': tag.setTitle, 'plot': tag.setPlot, 'tvshowtitle': tag.setTvShowTitle,
               'mediatype': tag.setMediaType, 'premiered': tag.setPremiered, 'aired': tag.setFirstAired,
               'dateadded': tag.setDateAdded, 'year': tag.setYear, 'duration': tag.setDuration,
               'director': tag.setDirectors}
    for key, value in info.items():
        setters[key](value)


def main(argv):
    Plugin(argv).run()
