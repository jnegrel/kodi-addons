"""Entry point that Kodi runs (see addon.xml); the work is in resources/lib/weather.py."""

import sys

from resources.lib import weather

weather.main(sys.argv)
