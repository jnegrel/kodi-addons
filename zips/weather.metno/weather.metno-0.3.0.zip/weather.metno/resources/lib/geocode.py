"""Place search, without any Kodi code.

MET Norway has no place-name search, so two other services are used:
- Kartverket's place-name register (Norway only, very complete),
  https://ws.geonorge.no/stedsnavn/v1/
- OpenStreetMap Nominatim (the whole world). Its policy allows an occasional
  search like ours (at most 1 request per second, with an identifying User-Agent),
  https://operations.osmfoundation.org/policies/nominatim/
"""

import json
import urllib.parse
import urllib.request

from .metno import http_get

KARTVERKET_URL = 'https://ws.geonorge.no/stedsnavn/v1/navn?{}'
NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search?{}'
MAX_RESULTS = 10


def kartverket(query, user_agent, opener=urllib.request.urlopen):
    params = urllib.parse.urlencode({'sok': query, 'fuzzy': 'true', 'utkoordsys': 4258,
                                     'treffPerSide': MAX_RESULTS})
    _, _, body = http_get(KARTVERKET_URL.format(params), user_agent, opener=opener)
    places = []
    for item in json.loads(body).get('navn', []):
        point = item.get('representasjonspunkt') or {}
        if 'nord' not in point:
            continue
        municipality = ', '.join(k['kommunenavn'] for k in item.get('kommuner', []))
        county = ', '.join(f['fylkesnavn'] for f in item.get('fylker', []))
        places.append({
            'name': item['skrivemåte'],
            'detail': ', '.join(x for x in (item.get('navneobjekttype'), municipality, county, 'Norge') if x),
            'lat': round(point['nord'], 4),
            'lon': round(point['øst'], 4),
        })
    return places


def nominatim(query, user_agent, language='en', opener=urllib.request.urlopen):
    params = urllib.parse.urlencode({'q': query, 'format': 'jsonv2', 'limit': MAX_RESULTS,
                                     'accept-language': language})
    _, _, body = http_get(NOMINATIM_URL.format(params), user_agent, opener=opener)
    places = []
    for item in json.loads(body):
        name, _, detail = item['display_name'].partition(', ')
        places.append({
            'name': name,
            'detail': detail,
            'lat': round(float(item['lat']), 4),
            'lon': round(float(item['lon']), 4),
        })
    return places


def search(query, user_agent, language='en', opener=urllib.request.urlopen):
    """Kartverket results first, then Nominatim, without places found by both,
    best matches first.
    A failing service is skipped as long as the other one answers."""
    results, errors = [], []
    for service in (lambda: kartverket(query, user_agent, opener),
                    lambda: nominatim(query, user_agent, language, opener)):
        try:
            results += service()
        except (OSError, ValueError) as error:
            errors.append(error)
    if not results and len(errors) == 2:
        raise errors[0]

    unique, seen = [], set()
    for place in results:
        key = (place['name'].lower(), round(place['lat'], 1), round(place['lon'], 1))
        if key not in seen:
            seen.add(key)
            unique.append(place)
    # Kartverket's approximate search returns Norwegian places with a similar name
    # ('Malo' for 'Saint-Malo'): names equal to the query first, then names starting with it
    wanted = query.strip().lower()
    unique.sort(key=lambda place: 0 if place['name'].lower() == wanted
                else 1 if place['name'].lower().startswith(wanted) else 2)
    return unique
