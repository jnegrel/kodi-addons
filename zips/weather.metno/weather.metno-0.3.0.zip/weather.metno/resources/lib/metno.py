"""Client for MET Norway's weather API, without any Kodi code.

Products used:
- Locationforecast 2.0: the forecast for the next 10 days, anywhere in the world,
- Nowcast 2.0: radar-based precipitation for the next 2 hours, Nordic area only,
- Sunrise 3.0: sunrise and sunset,
- MetAlerts 2.0: weather warnings, for Norway and Norwegian waters only.

Terms of service (https://api.met.no/doc/TermsOfService):
- every request sends a User-Agent that identifies the application,
- coordinates have at most 4 decimals,
- a response is reused until its Expires time, then revalidated with
  If-Modified-Since (the server answers 304 when nothing changed).
"""

import gzip
import http.client
import json
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

API = 'https://api.met.no/weatherapi/'
FORECAST_URL = API + 'locationforecast/2.0/complete?lat={lat}&lon={lon}'
NOWCAST_URL = API + 'nowcast/2.0/complete?lat={lat}&lon={lon}'
SUN_URL = API + 'sunrise/3.0/sun?lat={lat}&lon={lon}&date={date}&offset={offset}'
ALERTS_URL = API + 'metalerts/2.0/current.json?lat={lat}&lon={lon}&lang={lang}'
TIMEOUT = 20
DAY = 24 * 3600
WET = 0.1  # mm/h: less than this on the radar counts as dry


def http_get(url, user_agent, headers=None, opener=urllib.request.urlopen):
    """GET a URL. Returns (status, headers, body bytes); 304 is not an error."""
    request = urllib.request.Request(url, headers={
        'User-Agent': user_agent, 'Accept-Encoding': 'gzip', **(headers or {})})
    try:
        with opener(request, timeout=TIMEOUT) as response:
            body = response.read()
            if response.headers.get('Content-Encoding') == 'gzip':
                body = gzip.decompress(body)
            return response.status, response.headers, body
    except urllib.error.HTTPError as error:
        if error.code == 304:
            return 304, error.headers, b''
        raise


def _expires(headers, now):
    try:
        return parsedate_to_datetime(headers['Expires']).timestamp()
    except (KeyError, TypeError, ValueError):
        return now + 30 * 60


def _coordinates(lat, lon):
    return round(float(lat), 4), round(float(lon), 4)


class Client:
    def __init__(self, user_agent, cache_dir, opener=urllib.request.urlopen, clock=time.time):
        self.user_agent = user_agent
        self.cache_dir = cache_dir
        self.opener = opener
        self.clock = clock

    def forecast(self, lat, lon):
        """Raw Locationforecast JSON for a place."""
        lat, lon = _coordinates(lat, lon)
        return self._get('forecast_{}_{}'.format(lat, lon), FORECAST_URL.format(lat=lat, lon=lon))

    def nowcast(self, lat, lon):
        """Raw Nowcast JSON for a place, or None outside the Nordic area."""
        lat, lon = _coordinates(lat, lon)
        return self._get('nowcast_{}_{}'.format(lat, lon), NOWCAST_URL.format(lat=lat, lon=lon))

    def sun(self, lat, lon, date, offset):
        """Raw Sunrise JSON for a place and a date; times are given with the UTC offset
        offset ('+01:00'). The times of a date do not change, so they are kept for a day."""
        lat, lon = _coordinates(lat, lon)
        return self._get('sun_{}_{}_{}'.format(lat, lon, date.isoformat()),
                         SUN_URL.format(lat=lat, lon=lon, date=date.isoformat(), offset=offset),
                         lifetime=DAY)

    def alerts(self, lat, lon, language='en'):
        """Raw MetAlerts GeoJSON with the warnings in force at a place; MET writes
        them in Norwegian ('no') or English ('en')."""
        lat, lon = _coordinates(lat, lon)
        return self._get('alerts_{}_{}_{}'.format(lat, lon, language),
                         ALERTS_URL.format(lat=lat, lon=lon, lang=language))

    def _get(self, name, url, lifetime=None):
        """JSON from the cache while it is valid, else from MET. When the network
        fails, outdated data is better than none. None when MET answers that the
        place is outside the area of the product (HTTP 422), which is remembered for a day."""
        path = os.path.join(self.cache_dir, name + '.json')
        cached = _read_json(path)
        now = self.clock()
        if cached and now < cached['expires']:
            return cached['data']

        headers = {'If-Modified-Since': cached['last_modified']} if cached and cached.get('last_modified') else {}
        try:
            status, response_headers, body = http_get(url, self.user_agent, headers, self.opener)
            data = cached['data'] if status == 304 and cached else json.loads(body)
        except urllib.error.HTTPError as error:
            if error.code == 422:
                _write_json(path, {'expires': now + DAY, 'data': None})
                return None
            if cached:
                return cached['data']
            raise
        # OSError covers network errors, the others a response cut off on the way
        # (seen as 'Unterminated string' from json)
        except (OSError, http.client.HTTPException, EOFError, ValueError):
            if cached:
                return cached['data']
            raise
        _write_json(path, {
            'expires': now + lifetime if lifetime else _expires(response_headers, now),
            'last_modified': response_headers.get('Last-Modified') or (cached or {}).get('last_modified'),
            'data': data,
        })
        return data

    def remember_today(self, lat, lon, parsed):
        """Widens today's high and low in a parsed forecast with the values seen by
        earlier runs today: late in the day MET only sends the hours that are left."""
        if not parsed['daily']:
            return
        today = parsed['daily'][0]
        lat, lon = _coordinates(lat, lon)
        path = os.path.join(self.cache_dir, 'today_{}_{}.json'.format(lat, lon))
        saved = _read_json(path) or {}
        if saved.get('date') != today['date'].isoformat():
            saved = {'date': today['date'].isoformat()}
        for key, pick in (('high', max), ('low', min)):
            values = [v for v in (saved.get(key), today[key]) if v is not None]
            if values:
                today[key] = saved[key] = pick(values)
        _write_json(path, saved)

    def prune(self, age=3 * DAY):
        """Deletes cache files not written for a while (old dates, removed places)."""
        try:
            names = os.listdir(self.cache_dir)
        except OSError:
            return
        for name in names:
            path = os.path.join(self.cache_dir, name)
            try:
                if os.path.getmtime(path) < self.clock() - age:
                    os.remove(path)
            except OSError:
                pass


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _write_json(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + '.tmp'
    with open(temporary, 'w', encoding='utf-8') as f:
        json.dump(content, f)
    os.replace(temporary, path)


# ---------------------------------------------------------------- parsing

def _time(text):
    return datetime.fromisoformat(text.replace('Z', '+00:00'))


def _symbol(data, *periods):
    for period in periods:
        symbol = data.get(period, {}).get('summary', {}).get('symbol_code')
        if symbol:
            return symbol
    return None


def _point(step, tz, period_hours):
    """One timestep as a flat dict. 'period' is the precipitation period that
    belongs to this step: 1 h in the hourly part of the forecast, 6 h later on."""
    data = step['data']
    instant = data['instant']['details']
    period = data.get('next_1_hours' if period_hours == 1 else 'next_6_hours', {})
    details = period.get('details', {})
    return {
        'time': _time(step['time']).astimezone(tz),
        'period_hours': period_hours if period else 0,
        'temperature': instant.get('air_temperature'),
        'feels_like': instant.get('apparent_air_temperature'),
        'dew_point': instant.get('dew_point_temperature'),
        'humidity': instant.get('relative_humidity'),
        'pressure': instant.get('air_pressure_at_sea_level'),
        'cloudiness': instant.get('cloud_area_fraction'),
        'fog': instant.get('fog_area_fraction'),
        'uv': instant.get('ultraviolet_index_clear_sky'),
        'wind_speed': instant.get('wind_speed'),
        'wind_gust': instant.get('wind_speed_of_gust'),
        'wind_direction': instant.get('wind_from_direction'),
        'symbol': _symbol(data, 'next_1_hours', 'next_6_hours', 'next_12_hours') if period_hours == 1
        else _symbol(data, 'next_6_hours', 'next_12_hours'),
        'symbol_12h': _symbol(data, 'next_12_hours'),
        'precipitation': details.get('precipitation_amount'),
        'precipitation_probability': details.get('probability_of_precipitation'),
        'temperature_min': data.get('next_6_hours', {}).get('details', {}).get('air_temperature_min'),
        'temperature_max': data.get('next_6_hours', {}).get('details', {}).get('air_temperature_max'),
    }


def parse(forecast, now=None, tz=None):
    """Locationforecast JSON -> {'updated', 'current', 'hourly', 'daily'}.

    Times are converted to tz (default: the local time zone of the machine).
    'hourly' holds the 1-hour steps from now on, 'daily' one entry per local day.
    """
    now = now or datetime.now(timezone.utc)
    steps = forecast['properties']['timeseries']
    times = [_time(s['time']) for s in steps]
    points = []
    for i, step in enumerate(steps):
        gap = (times[i + 1] - times[i]) if i + 1 < len(steps) else timedelta(hours=6)
        points.append(_point(step, tz, 1 if gap <= timedelta(hours=1) else 6))

    past = [p for p in points if p['time'] <= now]
    current = past[-1] if past else points[0]
    hourly = [p for p in points if p['period_hours'] == 1 and p['time'] >= current['time']]

    return {
        'updated': _time(forecast['properties']['meta']['updated_at']).astimezone(tz),
        'current': current,
        'hourly': hourly,
        'daily': _days([p for p in points if p['time'] >= current['time']]),
    }


def _days(points):
    by_date = {}
    for p in points:
        by_date.setdefault(p['time'].date(), []).append(p)

    days = []
    for index, (date, day_points) in enumerate(sorted(by_date.items())):
        covered = sum(p['period_hours'] for p in day_points)
        if index > 0 and covered < 12:
            continue  # the last day of the forecast is often only a few hours long
        temperatures = [p['temperature'] for p in day_points]
        for p in day_points:
            if p['period_hours'] == 6:
                temperatures += [p['temperature_min'], p['temperature_max']]
        temperatures = [t for t in temperatures if t is not None]
        windiest = max(day_points, key=lambda p: p['wind_speed'] or 0)
        clouds = [p['cloudiness'] for p in day_points if p['cloudiness'] is not None]
        probabilities = [p['precipitation_probability'] for p in day_points
                         if p['precipitation_probability'] is not None]
        days.append({
            'date': date,
            'high': max(temperatures) if temperatures else None,
            'low': min(temperatures) if temperatures else None,
            'symbol': _day_symbol(day_points),
            'precipitation': round(sum(p['precipitation'] or 0 for p in day_points), 1),
            'precipitation_probability': max(probabilities) if probabilities else None,
            'cloudiness': sum(clouds) / len(clouds) if clouds else None,
            'wind_speed': windiest['wind_speed'],
            'wind_direction': windiest['wind_direction'],
        })
    return days


def _day_symbol(points):
    """The 12-hour symbol starting closest to 06:00 local time, like Yr shows it
    for a whole day. Later in the day this is the symbol for what is left of it."""
    candidates = [p for p in points if p['symbol_12h']] or [p for p in points if p['symbol']]
    if not candidates:
        return None
    best = min(candidates, key=lambda p: abs(p['time'].hour - 6) if p['time'].hour >= 6 else 24)
    return best['symbol_12h'] or best['symbol']


def parse_nowcast(nowcast, now=None, tz=None):
    """Nowcast JSON -> {'current': the latest values, like a point of parse(),
    'radar': whether the radar covers the place now, 'rates': [(time, mm/h)] from now on,
    'outlook': see precipitation_outlook()}, or None outside the Nordic area."""
    if not nowcast:
        return None
    now = now or datetime.now(timezone.utc)
    steps = nowcast['properties']['timeseries']
    past = [s for s in steps if _time(s['time']) <= now]
    first = past[-1] if past else steps[0]
    data = first['data']
    instant = data['instant']['details']
    result = {
        'current': {
            'time': _time(first['time']).astimezone(tz),
            'temperature': instant.get('air_temperature'),
            'feels_like': instant.get('apparent_air_temperature'),
            'humidity': instant.get('relative_humidity'),
            'wind_speed': instant.get('wind_speed'),
            'wind_gust': instant.get('wind_speed_of_gust'),
            'wind_direction': instant.get('wind_from_direction'),
            'symbol': _symbol(data, 'next_1_hours'),
        },
        'radar': nowcast['properties']['meta'].get('radar_coverage') == 'ok',
        'rates': [(_time(s['time']).astimezone(tz), s['data']['instant']['details'].get('precipitation_rate'))
                  for s in steps if s is first or _time(s['time']) > now],
    }
    result['outlook'] = precipitation_outlook(result, now)
    return result


def precipitation_outlook(nowcast, now=None):
    """What the radar says about the next 2 hours, as (event, minutes from now):
    ('starts', 25), ('stops', 40), ('dry', 110) = dry for as long as the nowcast goes,
    ('wet', 110) = precipitation all the time; None without radar data."""
    if not nowcast or not nowcast['radar']:
        return None
    rates = [(t, r) for t, r in nowcast['rates'] if r is not None]
    if not rates:
        return None
    now = now or datetime.now(timezone.utc)

    def minutes(moment):
        return max(5, int(round((moment - now).total_seconds() / 300.0)) * 5)

    wet_now = rates[0][1] >= WET
    for moment, rate in rates[1:]:
        if (rate >= WET) != wet_now:
            return ('stops' if wet_now else 'starts'), minutes(moment)
    return ('wet' if wet_now else 'dry'), minutes(rates[-1][0])


def parse_sun(sun, tz=None):
    """Sunrise JSON -> {'sunrise', 'sunset': datetime or None,
    'polar': 'night' (the sun stays below the horizon), 'day' (midnight sun) or None}."""
    if not sun:
        return None
    properties = sun['properties']

    def moment(key):
        text = (properties.get(key) or {}).get('time')
        return datetime.fromisoformat(text).astimezone(tz) if text else None

    sunrise, sunset = moment('sunrise'), moment('sunset')
    polar = None
    if sunrise is None and sunset is None:
        polar = 'day' if (properties.get('solarnoon') or {}).get('visible') else 'night'
    return {'sunrise': sunrise, 'sunset': sunset, 'polar': polar}


def parse_alerts(alerts, now=None, tz=None, marine=False):
    """MetAlerts GeoJSON -> list of warnings, the most severe first:
    {'id', 'event', 'name', 'level' (2 yellow, 3 orange, 4 red), 'color', 'area',
    'description', 'consequences', 'instruction', 'start', 'end' (datetime or None)}.
    Warnings for the sea ('marine': gale for boats...) are left out unless marine is true."""
    if not alerts:
        return []
    now = now or datetime.now(timezone.utc)
    result = []
    for feature in alerts.get('features', []):
        properties = feature.get('properties', {})
        if properties.get('status', 'Actual') != 'Actual':
            continue  # exercises and tests
        if properties.get('geographicDomain') == 'marine' and not marine:
            continue
        # awareness_level is like '2; yellow; Moderate'
        level, _, rest = properties.get('awareness_level', '').partition(';')
        if not level.strip().isdigit() or int(level) < 2:
            continue
        interval = (feature.get('when') or {}).get('interval') or [None, None]
        start, end = [_time(t).astimezone(tz) if t else None for t in (interval + [None])[:2]]
        if end and end <= now:
            continue
        result.append({
            'id': properties.get('id'),
            'event': properties.get('event', ''),
            'name': properties.get('eventAwarenessName') or properties.get('event', ''),
            'level': int(level),
            'color': rest.split(';')[0].strip().lower(),
            'area': properties.get('area', ''),
            'description': (properties.get('description') or '').strip(),
            'consequences': (properties.get('consequences') or '').strip(),
            'instruction': (properties.get('instruction') or '').strip(),
            'start': start,
            'end': end,
        })
    result.sort(key=lambda a: (-a['level'], a['start'] or now))
    return result


def alert_key(alert):
    """Identifies a warning across MET's updates of it; a higher level is a new warning."""
    return '{}|{}|{}'.format(alert['event'], alert['area'], alert['level'])
