"""MET Norway weather symbols -> Kodi weather icons and condition texts.

MET symbol codes are a base name, optionally with a _day, _night or
_polartwilight suffix (e.g. "partlycloudy_night"). Kodi skins draw icons
numbered 0-47 (the old weather.com codes) from their own icon set.
The legend of MET symbols: https://api.met.no/weatherapi/weathericon/2.0/documentation
"""

NA = 'na'

# base symbol: (Kodi icon by day, Kodi icon by night, id of the text in strings.po)
SYMBOLS = {
    'clearsky': (32, 31, 32200),
    'fair': (34, 33, 32201),
    'partlycloudy': (30, 29, 32202),
    'cloudy': (26, 26, 32203),
    'fog': (20, 20, 32204),
    'lightrainshowers': (39, 45, 32205),
    'rainshowers': (39, 45, 32206),
    'heavyrainshowers': (40, 45, 32207),
    'lightrainshowersandthunder': (37, 47, 32208),
    'rainshowersandthunder': (38, 47, 32209),
    'heavyrainshowersandthunder': (4, 4, 32210),
    'lightsleetshowers': (18, 18, 32211),
    'sleetshowers': (18, 18, 32212),
    'heavysleetshowers': (18, 18, 32213),
    'lightssleetshowersandthunder': (4, 4, 32214),  # sic, MET's spelling
    'sleetshowersandthunder': (4, 4, 32215),
    'heavysleetshowersandthunder': (4, 4, 32216),
    'lightsnowshowers': (14, 46, 32217),
    'snowshowers': (42, 46, 32218),
    'heavysnowshowers': (41, 46, 32219),
    'lightssnowshowersandthunder': (4, 4, 32220),  # sic, MET's spelling
    'snowshowersandthunder': (4, 4, 32221),
    'heavysnowshowersandthunder': (4, 4, 32222),
    'lightrain': (9, 9, 32223),
    'rain': (12, 12, 32224),
    'heavyrain': (40, 40, 32225),
    'lightrainandthunder': (4, 4, 32226),
    'rainandthunder': (4, 4, 32227),
    'heavyrainandthunder': (3, 3, 32228),
    'lightsleet': (18, 18, 32229),
    'sleet': (18, 18, 32230),
    'heavysleet': (18, 18, 32231),
    'lightsleetandthunder': (4, 4, 32232),
    'sleetandthunder': (4, 4, 32233),
    'heavysleetandthunder': (4, 4, 32234),
    'lightsnow': (14, 14, 32235),
    'snow': (16, 16, 32236),
    'heavysnow': (41, 41, 32237),
    'lightsnowandthunder': (4, 4, 32238),
    'snowandthunder': (4, 4, 32239),
    'heavysnowandthunder': (4, 4, 32240),
}


def split(symbol):
    """'partlycloudy_night' -> ('partlycloudy', 'night'); 'rain' -> ('rain', '')."""
    base, _, variant = (symbol or '').partition('_')
    return base, variant


def kodi_icon(symbol, force_day=False):
    """Kodi icon number as a string ('32'), or 'na' for an unknown symbol."""
    base, variant = split(symbol)
    if base not in SYMBOLS:
        return NA
    day, night, _ = SYMBOLS[base]
    return str(night if variant == 'night' and not force_day else day)


def text_id(symbol):
    """Id of the condition text in strings.po, or None for an unknown symbol."""
    base, _ = split(symbol)
    return SYMBOLS[base][2] if base in SYMBOLS else None


def precipitation_kind(symbol):
    """'rain', 'sleet' or 'snow' for a symbol with precipitation, else None."""
    base, _ = split(symbol)
    for kind in ('rain', 'sleet', 'snow'):
        if kind in base:
            return kind
    return None
