"""Unit conversions, without any Kodi code.

Kodi converts the standard weather properties (Current.Temperature, Day0.HighTemp,
Current.Wind...) itself and wants them in °C and km/h. The extra properties
(Hourly.*, Daily.*) are shown as they are, so they are formatted here in the
units of Kodi's regional settings (xbmc.getRegion('tempunit') / ('speedunit')).
"""

BEAUFORT_LIMITS = (0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7)  # m/s


def temperature(celsius, unit='°C'):
    """Temperature as a number in the given unit (°C, °F or K)."""
    if unit == '°F':
        return celsius * 9 / 5 + 32
    if unit == 'K':
        return celsius + 273.15
    return celsius


def format_temperature(celsius, unit='°C'):
    if celsius is None:
        return ''
    if unit not in ('°C', '°F', 'K'):
        unit = '°C'
    return '{}{}'.format(round(temperature(celsius, unit)), unit)


def format_speed(metres_per_second, unit='km/h'):
    if metres_per_second is None:
        return ''
    if unit == 'm/s':
        return '{:.0f} m/s'.format(metres_per_second)
    if unit == 'mph':
        return '{:.0f} mph'.format(metres_per_second * 2.23694)
    if unit == 'kts':
        return '{:.0f} kts'.format(metres_per_second * 1.94384)
    if unit == 'Beaufort':
        return '{} Bft'.format(sum(metres_per_second >= limit for limit in BEAUFORT_LIMITS))
    return '{:.0f} km/h'.format(metres_per_second * 3.6)


def km_per_hour(metres_per_second):
    return metres_per_second * 3.6 if metres_per_second is not None else None


def compass_index(degrees):
    """0 = N, 1 = NNE ... 15 = NNW (16 compass points)."""
    return int((degrees % 360) / 22.5 + 0.5) % 16
