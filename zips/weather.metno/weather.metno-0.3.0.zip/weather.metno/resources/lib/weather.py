"""The Kodi side of the add-on: settings, dialogs and weather window properties.

Kodi runs default.py with one argument:
- '1' to '5': fetch the weather for that location and publish it as properties
  of the weather window (id 12600), which the skin shows;
- 'Location1' to 'Location5': from the settings, search a place for that location;
- 'Alerts': from the settings, show the weather warnings for all locations.
"""

import json
import os
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import geocode, metno, symbols, units

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
WINDOW = xbmcgui.Window(12600)
MAX_LOCATIONS = 5
MAX_HOURS = 48
MAX_DAYS = 10
MAX_ALERTS = 10
ALERT_LEVELS = {2: 32055, 3: 32056, 4: 32057}  # 'Yellow warning'...
ALERT_COLORS = {'yellow': 'FFFFD21E', 'orange': 'FFFF8C1A', 'red': 'FFFF4040'}
USER_AGENT = '{}/{} github.com/jnegrel/kodi-weather-metno'.format(ADDON_ID, ADDON.getAddonInfo('version'))


def main(argv):
    argument = argv[1] if len(argv) > 1 else '1'
    if argument.startswith('Location'):
        search_location(int(argument[len('Location'):]))
    elif argument == 'Alerts':
        show_alerts()
    else:
        refresh(int(argument) if argument.isdigit() else 1)


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(ADDON_ID, message), level)


def set_property(name, value):
    WINDOW.setProperty(name, '' if value is None else str(value))


# ---------------------------------------------------------------- locations

def profile_path(*names):
    return os.path.join(xbmcvfs.translatePath('special://profile/addon_data/{}'.format(ADDON_ID)), *names)


def new_client():
    return metno.Client(USER_AGENT, profile_path('cache'))


def configured_locations():
    """[(settings index, name, lat, lon)] of the locations that are filled in."""
    locations = []
    for index in range(1, MAX_LOCATIONS + 1):
        name = ADDON.getSetting('Location{}'.format(index))
        lat = ADDON.getSetting('Location{}Lat'.format(index))
        lon = ADDON.getSetting('Location{}Lon'.format(index))
        if name and lat and lon:
            locations.append((index, name, float(lat), float(lon)))
    return locations


def search_location(index):
    query = xbmcgui.Dialog().input(text(32020))
    if not query:
        return
    try:
        places = geocode.search(query, USER_AGENT, xbmc.getLanguage(xbmc.ISO_639_1) or 'en')
    except (OSError, ValueError) as error:
        log('place search failed: {}'.format(error), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), text(32023))
        return
    if not places:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), text(32021).format(query))
        return
    items = [xbmcgui.ListItem(place['name'], place['detail']) for place in places]
    choice = xbmcgui.Dialog().select(text(32022), items, useDetails=True)
    if choice < 0:
        return
    place = places[choice]
    ADDON.setSetting('Location{}'.format(index), place['name'])
    ADDON.setSetting('Location{}Lat'.format(index), str(place['lat']))
    ADDON.setSetting('Location{}Lon'.format(index), str(place['lon']))
    log('location {} set to {} ({}, {})'.format(index, place['name'], place['lat'], place['lon']))


# ---------------------------------------------------------------- weather

def refresh(requested):
    locations = configured_locations()
    for number in range(1, MAX_LOCATIONS + 1):
        set_property('Location{}'.format(number), locations[number - 1][1] if number <= len(locations) else '')
    set_property('Locations', len(locations))
    set_property('WeatherProvider', 'MET Norway')
    set_property('WeatherProviderLogo', os.path.join(ADDON.getAddonInfo('path'), 'resources', 'icon.png'))

    if not locations:
        clear_weather()
        log('no location set')
        return
    # Kodi numbers the locations that are filled in, from 1
    _, name, lat, lon = locations[requested - 1] if requested <= len(locations) else locations[0]

    client = new_client()
    client.prune()
    try:
        forecast = metno.parse(client.forecast(lat, lon))
        client.remember_today(lat, lon, forecast)
    except (OSError, ValueError, KeyError) as error:
        log('forecast for {} failed: {}'.format(name, error), xbmc.LOGERROR)
        clear_weather()
        return
    # Nowcast and sunrise are extras: the weather is shown without them if they fail
    nowcast = sun = None
    try:
        nowcast = metno.parse_nowcast(client.nowcast(lat, lon))
    except (OSError, ValueError, KeyError) as error:
        log('nowcast for {} failed: {}'.format(name, error), xbmc.LOGWARNING)
    try:
        today = datetime.now().astimezone()
        offset = today.strftime('%z')
        sun = metno.parse_sun(client.sun(lat, lon, today.date(), offset[:3] + ':' + offset[3:]))
    except (OSError, ValueError, KeyError) as error:
        log('sunrise for {} failed: {}'.format(name, error), xbmc.LOGWARNING)
    alerts = None
    try:
        alerts = fetch_alerts(client, lat, lon)
    except (OSError, ValueError, KeyError) as error:
        log('warnings for {} failed: {}'.format(name, error), xbmc.LOGWARNING)
    publish(name, lat, lon, forecast, nowcast, sun)
    publish_alerts(alerts or [])
    if alerts is not None:
        notify_alerts(alerts, '{},{}'.format(lat, lon))


def clear_weather():
    for flag in ('Weather.IsFetched', 'Current.IsFetched', 'Hourly.IsFetched', 'Daily.IsFetched'):
        set_property(flag, '')
    for prefix in (['Current'] + ['Day{}'.format(i) for i in range(7)]):
        for key in ('Condition', 'Temperature', 'OutlookIcon', 'FanartCode', 'HighTemp', 'LowTemp', 'Outlook', 'Title'):
            set_property('{}.{}'.format(prefix, key), '')


def precipitation_outlook(nowcast, forecast, current):
    """Short text from the radar about the next 2 hours ('Rain in 25 min'), or ''."""
    outlook = nowcast['outlook'] if nowcast else None
    if not outlook or outlook[0] == 'wet':
        return ''  # when it rains all the time, the amount for the next hour says more
    event, minutes = outlook
    if event == 'dry':
        return text(32046).format(minutes)
    symbol = current['symbol']
    if event == 'starts':
        # the forecast tells what kind of precipitation is coming
        start = nowcast['current']['time'].timestamp() + minutes * 60
        hours = [h for h in forecast['hourly'] if 0 <= start - h['time'].timestamp() < 3600]
        symbol = hours[0]['symbol'] if hours else symbol
    temperature = current['temperature'] if current['temperature'] is not None else 5
    kind = symbols.precipitation_kind(symbol) or (
        'snow' if temperature <= 0.5 else 'sleet' if temperature <= 1.5 else 'rain')
    first_id = 32040 if event == 'starts' else 32043
    return text(first_id + ('rain', 'sleet', 'snow').index(kind)).format(minutes)


def sun_time(sun, key, time_format):
    if not sun:
        return ''
    if sun['polar']:
        return text(32030 if sun['polar'] == 'night' else 32031)
    return sun[key].strftime(time_format) if sun[key] else ''


def publish(name, lat, lon, forecast, nowcast=None, sun=None):
    temperature_unit = xbmc.getRegion('tempunit')
    speed_unit = xbmc.getRegion('speedunit')
    time_format = xbmc.getRegion('time').replace(':%S', '')
    current = forecast['current']
    if nowcast:
        # In the Nordic area, the nowcast is closer to the weather of the moment
        current = dict(current, **{key: value for key, value in nowcast['current'].items()
                                   if value is not None and key != 'time'})

    def condition(symbol):
        string_id = symbols.text_id(symbol)
        return text(string_id) if string_id else ''

    def compass(degrees):
        return xbmc.getLocalizedString(71 + units.compass_index(degrees)) if degrees is not None else ''

    def rounded(value):
        return '' if value is None else str(round(value))

    def percent(value):
        return '' if value is None else '{}%'.format(round(value))

    def precipitation(value):
        return '' if value is None else '{:.1f} mm'.format(value)

    # Standard properties: Kodi converts °C and km/h to the user's units itself
    set_property('Current.Location', name)
    set_property('Current.Condition', condition(current['symbol']))
    set_property('Current.Temperature', rounded(current['temperature']))
    set_property('Current.FeelsLike', rounded(current['feels_like']))
    set_property('Current.DewPoint', rounded(current['dew_point']))
    set_property('Current.Humidity', rounded(current['humidity']))
    set_property('Current.UVIndex', rounded(current['uv']))
    set_property('Current.Wind', rounded(units.km_per_hour(current['wind_speed'])))
    set_property('Current.WindDirection', compass(current['wind_direction']))
    set_property('Current.OutlookIcon', symbols.kodi_icon(current['symbol']) + '.png')
    set_property('Current.FanartCode', symbols.kodi_icon(current['symbol']))
    # Extra properties used by many skins
    set_property('Current.Precipitation', precipitation_outlook(nowcast, forecast, current)
                 or precipitation(current['precipitation']))
    set_property('Current.ChancePrecipitation', rounded(current['precipitation_probability']))
    set_property('Current.Cloudiness', rounded(current['cloudiness']))
    set_property('Current.Pressure', rounded(current['pressure']))
    set_property('Current.WindGust', units.format_speed(current['wind_gust'], speed_unit))
    set_property('Today.Sunrise', sun_time(sun, 'sunrise', time_format))
    set_property('Today.Sunset', sun_time(sun, 'sunset', time_format))
    set_property('Forecast.City', name)
    set_property('Forecast.Latitude', lat)
    set_property('Forecast.Longitude', lon)
    set_property('Forecast.Updated', forecast['updated'].strftime(time_format))

    for number in range(1, MAX_HOURS + 1):
        prefix = 'Hourly.{}.'.format(number)
        hour = forecast['hourly'][number - 1] if number <= len(forecast['hourly']) else None
        if hour is None:
            for key in ('Time', 'Outlook', 'OutlookIcon', 'Temperature'):
                set_property(prefix + key, '')
            continue
        moment = hour['time']
        set_property(prefix + 'Time', moment.strftime(time_format))
        set_property(prefix + 'ShortDate', '{} {}'.format(moment.day, xbmc.getLocalizedString(51 + moment.month - 1)))
        set_property(prefix + 'LongDate', '{} {}'.format(moment.day, xbmc.getLocalizedString(21 + moment.month - 1)))
        set_property(prefix + 'Outlook', condition(hour['symbol']))
        set_property(prefix + 'OutlookIcon', symbols.kodi_icon(hour['symbol']) + '.png')
        set_property(prefix + 'FanartCode', symbols.kodi_icon(hour['symbol']))
        set_property(prefix + 'Temperature', units.format_temperature(hour['temperature'], temperature_unit))
        set_property(prefix + 'FeelsLike', units.format_temperature(hour['feels_like'], temperature_unit))
        set_property(prefix + 'DewPoint', units.format_temperature(hour['dew_point'], temperature_unit))
        set_property(prefix + 'Humidity', percent(hour['humidity']))
        set_property(prefix + 'Precipitation', precipitation(hour['precipitation']))
        set_property(prefix + 'ChancePrecipitation', percent(hour['precipitation_probability']))
        set_property(prefix + 'WindSpeed', units.format_speed(hour['wind_speed'], speed_unit))
        set_property(prefix + 'WindGust', units.format_speed(hour['wind_gust'], speed_unit))
        set_property(prefix + 'WindDirection', compass(hour['wind_direction']))
        set_property(prefix + 'Pressure', rounded(hour['pressure']))
        set_property(prefix + 'Cloudiness', percent(hour['cloudiness']))

    days = forecast['daily']
    for number in range(MAX_DAYS):
        day = days[number] if number < len(days) else None
        long_day = xbmc.getLocalizedString(11 + day['date'].weekday()) if day else ''
        if number < 7:
            # Day0 is today; Kodi converts these temperatures itself
            prefix = 'Day{}.'.format(number)
            set_property(prefix + 'Title', long_day)
            set_property(prefix + 'HighTemp', rounded(day['high']) if day else '')
            set_property(prefix + 'LowTemp', rounded(day['low']) if day else '')
            set_property(prefix + 'Outlook', condition(day['symbol']) if day else '')
            set_property(prefix + 'OutlookIcon', symbols.kodi_icon(day['symbol'], force_day=True) + '.png' if day else '')
            set_property(prefix + 'FanartCode', symbols.kodi_icon(day['symbol'], force_day=True) if day else '')
        # Daily.1 is today too: skins start their 10-day list with it
        prefix = 'Daily.{}.'.format(number + 1)
        if day is None:
            for key in ('ShortDay', 'LongDay', 'Outlook', 'OutlookIcon', 'HighTemperature', 'LowTemperature'):
                set_property(prefix + key, '')
            continue
        date = day['date']
        set_property(prefix + 'LongDay', long_day)
        set_property(prefix + 'ShortDay', xbmc.getLocalizedString(41 + date.weekday()))
        set_property(prefix + 'ShortDate', '{} {}'.format(date.day, xbmc.getLocalizedString(51 + date.month - 1)))
        set_property(prefix + 'LongDate', '{} {}'.format(date.day, xbmc.getLocalizedString(21 + date.month - 1)))
        set_property(prefix + 'Outlook', condition(day['symbol']))
        set_property(prefix + 'OutlookIcon', symbols.kodi_icon(day['symbol'], force_day=True) + '.png')
        set_property(prefix + 'FanartCode', symbols.kodi_icon(day['symbol'], force_day=True))
        set_property(prefix + 'HighTemperature', units.format_temperature(day['high'], temperature_unit))
        set_property(prefix + 'LowTemperature', units.format_temperature(day['low'], temperature_unit))
        set_property(prefix + 'Precipitation', precipitation(day['precipitation']))
        set_property(prefix + 'ChancePrecipitation', percent(day['precipitation_probability']))
        set_property(prefix + 'WindSpeed', units.format_speed(day['wind_speed'], speed_unit))
        set_property(prefix + 'WindDirection', compass(day['wind_direction']))
        set_property(prefix + 'Cloudiness', percent(day['cloudiness']))

    for flag in ('Weather.IsFetched', 'Current.IsFetched', 'Hourly.IsFetched', 'Daily.IsFetched'):
        set_property(flag, 'true')
    log('weather for {} published ({} hours, {} days)'.format(name, len(forecast['hourly']), len(days)))


# ---------------------------------------------------------------- warnings

def fetch_alerts(client, lat, lon):
    # MET writes its warnings in Norwegian or English
    language = 'no' if xbmc.getLanguage(xbmc.ISO_639_1) in ('nb', 'nn', 'no') else 'en'
    return metno.parse_alerts(client.alerts(lat, lon, language),
                              marine=ADDON.getSettingBool('AlertsMarine'))


def alert_heading(alert):
    """'Yellow warning: Gale'"""
    return '{}: {}'.format(text(ALERT_LEVELS.get(alert['level'], 32055)), alert['name'])


def alert_moment(value):
    """'Thu 06:00'"""
    if not value:
        return ''
    time_format = xbmc.getRegion('time').replace(':%S', '')
    return '{} {}'.format(xbmc.getLocalizedString(41 + value.weekday()), value.strftime(time_format))


def alert_period(alert):
    """'Wed 23:00 - Thu 06:00'"""
    return ' - '.join(m for m in (alert_moment(alert['start']), alert_moment(alert['end'])) if m)


def alert_icon(alert):
    return os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media', 'warning_{}.png'.format(alert['color']))


def publish_alerts(alerts):
    """Alerts.* properties for skins, and the most severe warning next to the provider
    name, which Estuary shows at the top of the weather window."""
    set_property('Alerts.Count', len(alerts))
    for number in range(1, MAX_ALERTS + 1):
        alert = alerts[number - 1] if number <= len(alerts) else None
        prefix = 'Alerts.{}.'.format(number)
        set_property(prefix + 'Heading', alert_heading(alert) if alert else '')
        set_property(prefix + 'Name', alert['name'] if alert else '')
        set_property(prefix + 'Event', alert['event'] if alert else '')
        set_property(prefix + 'Level', alert['level'] if alert else '')
        set_property(prefix + 'Color', alert['color'] if alert else '')
        set_property(prefix + 'Icon', alert_icon(alert) if alert else '')
        set_property(prefix + 'Area', alert['area'] if alert else '')
        set_property(prefix + 'Period', alert_period(alert) if alert else '')
        set_property(prefix + 'Description', alert['description'] if alert else '')
        set_property(prefix + 'Consequences', alert['consequences'] if alert else '')
        set_property(prefix + 'Instruction', alert['instruction'] if alert else '')
    provider = 'MET Norway'
    if alerts:
        provider += ' \u2013 ' + alert_heading(alerts[0])
        if len(alerts) > 1:
            provider += ' ' + text(32061).format(len(alerts) - 1)
    set_property('WeatherProvider', provider)
    set_property('Alerts.IsFetched', 'true')


def notify_alerts(alerts, place):
    """A notification for each warning not shown before (once per warning, again when
    its level goes up), except while a video plays: it then waits for a later refresh.
    The warnings shown are remembered per place, so that switching between places
    in the weather window does not show them again."""
    path = profile_path('alerts_seen.json')
    try:
        with open(path, encoding='utf-8') as f:
            seen = json.load(f)
    except (OSError, ValueError):
        seen = {}
    if not isinstance(seen, dict):
        seen = {}
    keys = [metno.alert_key(alert) for alert in alerts]
    new = [alert for alert, key in zip(alerts, keys) if key not in seen.get(place, [])]
    if new and (not ADDON.getSettingBool('AlertsNotify') or xbmc.Player().isPlayingVideo()):
        return
    if seen.get(place, []) == keys:
        return
    for alert in new:
        # the notification has room for one short line: the end matters most
        until = text(32065).format(alert_moment(alert['end'])) if alert['end'] else ''
        message = ', '.join(x for x in (until, alert['area']) if x)
        xbmcgui.Dialog().notification(alert_heading(alert), message, alert_icon(alert), 10000)
    seen[place] = keys  # only the warnings in force: the list does not grow
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(seen, f)
    except OSError as error:
        log('could not save the warnings shown: {}'.format(error), xbmc.LOGWARNING)


def show_alerts():
    """The full text of the warnings for all locations, from the settings."""
    client = new_client()
    sections = []
    for _, name, lat, lon in configured_locations():
        try:
            alerts = fetch_alerts(client, lat, lon)
        except (OSError, ValueError, KeyError) as error:
            log('warnings for {} failed: {}'.format(name, error), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), text(32062))
            return
        for alert in alerts:
            lines = ['[B][COLOR {}]{}[/COLOR][/B]'.format(
                ALERT_COLORS.get(alert['color'], 'FFFFFFFF'), alert_heading(alert)),
                '{}: {}'.format(name, alert['area']), alert_period(alert), '', alert['description']]
            if alert['consequences']:
                lines += ['', '[B]{}[/B]'.format(text(32059)), alert['consequences']]
            if alert['instruction']:
                lines += ['', '[B]{}[/B]'.format(text(32060)), alert['instruction']]
            sections.append('[CR]'.join(lines))
    xbmcgui.Dialog().textviewer(text(32050), '[CR][CR]'.join(sections) if sections else text(32058))
